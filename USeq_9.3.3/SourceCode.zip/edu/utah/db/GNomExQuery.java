package edu.utah.db;

public class GNomExQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
