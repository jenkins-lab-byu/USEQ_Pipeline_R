package edu.utah.seq.useq.data;

/**Container for Alignments*/
public class Alignments {
	
	
	private String[] cigars;
	private AlignmentCoordinate[] coordinates;
	
	
	
}
