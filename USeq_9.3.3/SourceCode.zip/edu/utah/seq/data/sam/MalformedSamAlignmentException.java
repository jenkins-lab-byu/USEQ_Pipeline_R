package edu.utah.seq.data.sam;

public class MalformedSamAlignmentException extends Exception{
	public MalformedSamAlignmentException(String message) {
	    super(message);
	  }
}
